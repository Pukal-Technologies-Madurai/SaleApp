import { ScrollView, StyleSheet, Text, TouchableOpacity, View, RefreshControl } from "react-native";
import React from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { useQuery } from "@tanstack/react-query";
import AsyncStorage from "@react-native-async-storage/async-storage";
import AppHeader from "../../Components/AppHeader";
import FilterModal from "../../Components/FilterModal";
import { fetchSaleOrder } from "../../Api/sales";
import { customColors, typography } from "../../Config/helper";

const PendingInvoice = () => {
    const navigation = useNavigation();
    const [userId, setUserId] = React.useState(null);
    const [companyId, setCompanyId] = React.useState("");
    const [modalVisible, setModalVisible] = React.useState(false);
    const [selectedFromDate, setSelectedFromDate] = React.useState(new Date().toISOString().split("T")[0]);
    const [selectedToDate, setSelectedToDate] = React.useState(new Date().toISOString().split("T")[0]);
    const [selectedBranch, setSelectedBranch] = React.useState(null);
    const [activeTab, setActiveTab] = React.useState("sales");

    const handleFromDateChange = date => {
        if (date) {
            const newFromDate = date > selectedToDate ? selectedToDate : date;
            setSelectedFromDate(newFromDate.toISOString().split("T")[0]);
        }
    };

    const handleToDateChange = date => {
        if (date) {
            const newToDate = date < selectedFromDate ? selectedFromDate : date;
            setSelectedToDate(newToDate.toISOString().split("T")[0]);
        }
    };

    const handleCloseModal = () => {
        setModalVisible(false);
    };

    React.useEffect(() => {
        (async () => {
            const userId = await AsyncStorage.getItem("UserId");
            const Company_Id = await AsyncStorage.getItem("Company_Id");
            const branchId = await AsyncStorage.getItem("branchId");
            let parsedBranchId = branchId;

            if (typeof branchId === "string") {
                parsedBranchId = parseInt(branchId.replace(/[\[\]]/g, ''));
            } else {
                parsedBranchId = parseInt(branchId);
            }

            setUserId(userId);
            setCompanyId(Company_Id);
            setSelectedBranch(parsedBranchId)
        })();

    }, [selectedFromDate, selectedToDate, selectedBranch]);

    const { data: totalSales = [], isLoading: isLoadingTotalSales, refetch: refetchTotalSales } = useQuery({
        queryKey: ["totalSales", selectedFromDate, selectedToDate, selectedBranch, userId, companyId],
        queryFn: () => fetchSaleOrder({
            from: selectedFromDate,
            to: selectedToDate,
            company: companyId,
            userId: userId,
            branchId: selectedBranch,
        }),
        enabled: !!selectedFromDate && !!selectedToDate && !!companyId && !!userId && !!selectedBranch,
    });

    const pendingSalesOrders = totalSales.filter(
        item => item.isConverted !== 2,
    );

    const pendingDeliveries = totalSales.filter(
        item => item.Delivery_Status !== 7 && item.totalSalesReturnQty === null,
    );

    const formatDate = dateString => {
        const date = new Date(dateString);
        return date.toLocaleDateString("en-GB");
    };

    const formatCurrency = amount => {
        return `₹${parseFloat(amount).toFixed(2)}`;
    };

    const onRefresh = () => {
        refetchTotalSales();
    };

    const renderSalesOrderCard = (item) => (
        <TouchableOpacity key={item.S_Id} style={styles.card}>
            <View style={styles.cardHeader}>
                <Text style={styles.invoiceNumber}>{item.So_Inv_No}</Text>
                <Text style={styles.amount}>{formatCurrency(item.Total_Invoice_value)}</Text>
            </View>

            <View style={styles.cardBody}>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Retailer:</Text>
                    <Text style={styles.value}>{item.Retailer_Name}</Text>
                </View>

                <View style={styles.infoRow}>
                    <Text style={styles.label}>Sales Person:</Text>
                    <Text style={styles.value}>{item.Sales_Person_Name}</Text>
                </View>

                <View style={styles.infoRow}>
                    <Text style={styles.label}>Date:</Text>
                    <Text style={styles.value}>{formatDate(item.So_Date)}</Text>
                </View>

                <View style={styles.infoRow}>
                    <Text style={styles.label}>Branch:</Text>
                    <Text style={styles.value}>{item.Branch_Name}</Text>
                </View>
            </View>

            <View style={styles.cardFooter}>
                <View style={[styles.statusBadge, styles.pendingBadge]}>
                    <Text style={styles.statusText}>Pending Conversion</Text>
                </View>
            </View>
        </TouchableOpacity>
    );

    const renderDeliveryCard = (item) => (
        <TouchableOpacity key={item.Do_Id} style={styles.card}>
            <View style={styles.cardHeader}>
                <Text style={styles.invoiceNumber}>{item.Do_Inv_No}</Text>
                <Text style={styles.amount}>{formatCurrency(item.Total_Invoice_value)}</Text>
            </View>

            <View style={styles.cardBody}>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Retailer:</Text>
                    <Text style={styles.value}>{item.Retailer_Name}</Text>
                </View>

                <View style={styles.infoRow}>
                    <Text style={styles.label}>Delivery Person:</Text>
                    <Text style={styles.value}>{item.Delivery_Person_Name}</Text>
                </View>

                <View style={styles.infoRow}>
                    <Text style={styles.label}>Date:</Text>
                    <Text style={styles.value}>{formatDate(item.Do_Date)}</Text>
                </View>

                <View style={styles.infoRow}>
                    <Text style={styles.label}>Route:</Text>
                    <Text style={styles.value}>{item.Routename} - {item.AreaName}</Text>
                </View>

                {item.Products_List && item.Products_List.length > 0 && (
                    <View style={styles.productsSection}>
                        <Text style={styles.productsHeader}>Products ({item.Products_List.length})</Text>
                        {item.Products_List.slice(0, 2).map((product, index) => (
                            <Text key={index} style={styles.productItem}>
                                • {product.Product_Name} (Qty: {product.Total_Qty})
                            </Text>
                        ))}
                        {item.Products_List.length > 2 && (
                            <Text style={styles.moreProducts}>
                                +{item.Products_List.length - 2} more items
                            </Text>
                        )}
                    </View>
                )}
            </View>

            <View style={styles.cardFooter}>
                <View style={[styles.statusBadge, item.Cancel_status === "1" ? styles.cancelledBadge : styles.pendingBadge]}>
                    <Text style={styles.statusText}>
                        {item.Cancel_status === "1" ? "Cancelled" : "Pending Delivery"}
                    </Text>
                </View>
            </View>
        </TouchableOpacity>
    );

    const renderEmptyState = (type) => (
        <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
                No pending {type === 'sales' ? 'sales orders' : 'deliveries'} found
            </Text>
            <Text style={styles.emptySubText}>
                {type === 'sales'
                    ? 'All sales orders have been converted to invoices'
                    : 'All deliveries have been completed'
                }
            </Text>
        </View>
    );


    return (
        <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
            <AppHeader
                title="Pending Details"
                navigation={navigation}
                showRightIcon={true}
                rightIconLibrary="MaterialIcon"
                rightIconName="filter-list"
                onRightPress={() => setModalVisible(true)}
            />

            <FilterModal
                visible={modalVisible}
                fromDate={selectedFromDate}
                toDate={selectedToDate}
                onFromDateChange={handleFromDateChange}
                onToDateChange={handleToDateChange}
                onApply={() => setModalVisible(false)}
                onClose={handleCloseModal}
                showToDate={true}
                title="Filter options"
                fromLabel="From Date"
                toLabel="To Date"
            />

            <View style={styles.contentContainer}>

                <View style={styles.tabContainer}>
                    <TouchableOpacity
                        style={[styles.tab, activeTab === 'sales' && styles.activeTab]}
                        onPress={() => setActiveTab('sales')}
                    >
                        <Text style={[styles.tabText, activeTab === 'sales' && styles.activeTabText]}>
                            Sales Orders ({pendingSalesOrders.length})
                        </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={[styles.tab, activeTab === 'delivery' && styles.activeTab]}
                        onPress={() => setActiveTab('delivery')}
                    >
                        <Text style={[styles.tabText, activeTab === 'delivery' && styles.activeTabText]}>
                            Deliveries ({pendingDeliveries.length})
                        </Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.summaryContainer}>
                    <View style={styles.summaryCard}>
                        <Text style={styles.summaryNumber}>{pendingSalesOrders.length}</Text>
                        <Text style={styles.summaryLabel}>Pending Sales</Text>
                    </View>

                    <View style={styles.summaryCard}>
                        <Text style={styles.summaryNumber}>{pendingDeliveries.length}</Text>
                        <Text style={styles.summaryLabel}>Pending Deliveries</Text>
                    </View>

                    <View style={styles.summaryCard}>
                        <Text style={styles.summaryNumber}>
                            {formatCurrency(
                                (activeTab === 'sales'
                                    ? pendingSalesOrders.reduce((sum, item) => sum + parseFloat(item.Total_Invoice_value || 0), 0)
                                    : pendingDeliveries.reduce((sum, item) => sum + parseFloat(item.Total_Invoice_value || 0), 0)
                                )
                            )}
                        </Text>
                        <Text style={styles.summaryLabel}>Total Value</Text>
                    </View>
                </View>

                <ScrollView
                    style={styles.listContainer}
                    refreshControl={
                        <RefreshControl
                            refreshing={isLoadingTotalSales}
                            onRefresh={onRefresh}
                            colors={[customColors.primary]}
                        />
                    }
                    showsVerticalScrollIndicator={false}
                >
                    {activeTab === 'sales' ? (
                        pendingSalesOrders.length > 0 ? (
                            pendingSalesOrders.map(renderSalesOrderCard)
                        ) : (
                            renderEmptyState('sales')
                        )
                    ) : (
                        pendingDeliveries.length > 0 ? (
                            pendingDeliveries.map(renderDeliveryCard)
                        ) : (
                            renderEmptyState('delivery')
                        )
                    )}
                </ScrollView>
            </View>
        </SafeAreaView>
    )
}

export default PendingInvoice

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: customColors.primaryDark,
    },
    contentContainer: {
        flex: 1,
        backgroundColor: customColors.white,
    },
    tabContainer: {
        flexDirection: 'row',
        backgroundColor: customColors.lightGray,
        margin: 16,
        borderRadius: 8,
        padding: 4,
    },
    tab: {
        flex: 1,
        paddingVertical: 12,
        paddingHorizontal: 16,
        borderRadius: 6,
        alignItems: 'center',
    },
    activeTab: {
        backgroundColor: customColors.primary,
    },
    tabText: {
        fontSize: 14,
        fontWeight: '600',
        color: customColors.textSecondary,
    },
    activeTabText: {
        color: customColors.white,
    },
    summaryContainer: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        marginBottom: 16,
    },
    summaryCard: {
        flex: 1,
        backgroundColor: customColors.lightBlue,
        padding: 16,
        borderRadius: 8,
        alignItems: 'center',
        marginHorizontal: 4,
    },
    summaryNumber: {
        fontSize: 20,
        fontWeight: 'bold',
        color: customColors.primary,
        marginBottom: 4,
    },
    summaryLabel: {
        fontSize: 12,
        color: customColors.textSecondary,
        textAlign: 'center',
    },
    listContainer: {
        flex: 1,
        paddingHorizontal: 16,
    },
    card: {
        backgroundColor: customColors.white,
        borderRadius: 12,
        marginBottom: 16,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.1,
        shadowRadius: 3.84,
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: customColors.lightGray,
    },
    invoiceNumber: {
        fontSize: 16,
        fontWeight: 'bold',
        color: customColors.textPrimary,
    },
    amount: {
        fontSize: 16,
        fontWeight: 'bold',
        color: customColors.primary,
    },
    cardBody: {
        padding: 16,
    },
    infoRow: {
        flexDirection: 'row',
        marginBottom: 8,
    },
    label: {
        fontSize: 14,
        color: customColors.textSecondary,
        width: 100,
        fontWeight: '500',
    },
    value: {
        fontSize: 14,
        color: customColors.textPrimary,
        flex: 1,
        fontWeight: '400',
    },
    productsSection: {
        marginTop: 12,
        paddingTop: 12,
        borderTopWidth: 1,
        borderTopColor: customColors.lightGray,
    },
    productsHeader: {
        fontSize: 14,
        fontWeight: '600',
        color: customColors.textPrimary,
        marginBottom: 8,
    },
    productItem: {
        fontSize: 13,
        color: customColors.textSecondary,
        marginBottom: 4,
        marginLeft: 8,
    },
    moreProducts: {
        fontSize: 13,
        color: customColors.primary,
        fontStyle: 'italic',
        marginLeft: 8,
    },
    cardFooter: {
        paddingHorizontal: 16,
        paddingBottom: 16,
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    statusBadge: {
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
    },
    pendingBadge: {
        backgroundColor: customColors.warning + '20',
    },
    cancelledBadge: {
        backgroundColor: customColors.error + '20',
    },
    statusText: {
        fontSize: 12,
        fontWeight: '600',
        color: customColors.warning,
    },
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 60,
    },
    emptyText: {
        fontSize: 16,
        fontWeight: '600',
        color: customColors.textSecondary,
        marginBottom: 8,
    },
    emptySubText: {
        fontSize: 14,
        color: customColors.textSecondary,
        textAlign: 'center',
        paddingHorizontal: 40,
    },
})