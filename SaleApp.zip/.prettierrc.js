module.exports = {
    arrowParens: "avoid",
    // bracketSameLine: true,
    // bracketSpacing: true,
    singleQuote: false,
    trailingComma: "all",
    tabWidth: 4,
    // semi: true,
};
